class Education {
  String from;
  String to;
  String organization;
  String post;

  Education(this.from, this.to, this.organization, this.post);
}
