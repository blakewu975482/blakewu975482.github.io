class Fonts {
  Fonts._();

  static const String product = 'ProductSans';
  static const String nexa_light = 'NexaLight';
  static const String nexa_bold = 'NexaBold';

}